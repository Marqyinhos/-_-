import java.util.Scanner; 
import java.util.*;
import java.lang.*;


public class triangle {
	
	 public static int perimetr(int h, int base) {
		 int triangle = base*3;
		 int rectangle = h*2+base*2;
		 int sum = triangle+ rectangle;
		 String Binary = Integer.toBinaryString(sum);
		 int result = Integer.parseInt (Binary);
		 int one=0;
		 for(int i=0; i< Binary.length();i++) {
			 if(result%10 == 1) {
				 one++;
			 }
			 result = result/10;
		 }
		 return one;
		 
		 
	 }

}
