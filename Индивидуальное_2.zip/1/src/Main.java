import java.util.Scanner;


public class Main {
	
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
	    System.out.print("Write h: ");
	    int h = console.nextInt();
	    System.out.print("Write base: ");
	    int base = console.nextInt();
	    console.close();
	    
	    
	    System.out.println("Sum = "+triangle.perimetr(h, base));
	}
}
